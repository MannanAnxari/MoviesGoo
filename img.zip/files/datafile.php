<?php 
  // $datafile = 'https://raw.githubusercontent.com/sizzlingkenny/MoviesGoo-movie-script-php/main/data.json'; //keep this link for auto movie updates
 $datafile = 'data.json'; // uncomment this line and comment the above line for movies data loaded locally
?>
