<!-- footer -->
<footer class="footer">
	<div class="container">
		<div class="row">
			<div class="col-12">
				<div class="footer__content">
					<a href="/" class="footer__logo" style="font-size:25px;font-family:tahoma;font-weight:bold;">
						<span style="color:#7ac37d;">MOVIES</span><span style="color:#fff;">GOO</span>
					</a>
					
					<span class="footer__copyright"><a rel="nofollow" href="https://www.google.com/search?q=moviesgoo.com" target="_blank">MoviesGoo</a> © 2023 <br></span>

					<nav class="footer__nav">
						<a rel="nofollow" href="//wa.me/+923131232025" target="_blank">Download Script</a>
					</nav>

					<button class="footer__back" type="button">
						<i class="icon ion-ios-arrow-round-up"></i>
					</button>
				</div>
			</div>
		</div>
	</div>
</footer>
<!-- end footer -->


<!--
<script type="text/javascript">
	atOptions = {
		'key' : 'ba8b6a9064816ee10282e5fc2c7e36ee',
		'format' : 'iframe',
		'height' : 250,
		'width' : 300,
		'params' : {}
	};
	document.write('<scr' + 'ipt type="text/javascript" src="http' + (location.protocol === 'https:' ? 's' : '') + '://www.profitabledisplaynetwork.com/ba8b6a9064816ee10282e5fc2c7e36ee/invoke.js"></scr' + 'ipt>');
</script>
<a href="https://www.highrevenuegate.com/jrtni4ap55?key=79071d2d7d447591b149941ccddd8edd">Nope!</a>
<script type='text/javascript' src='//pl19916956.highrevenuegate.com/e5/a2/4b/e5a24bd0e32733c470230f5386d833bc.js'></script>

-->
<?php 
// don't change anything below here, all the following files are required
echo 
'<script src="./js/jquery-3.5.1.min.js"></script>
<script src="./js/bootstrap.bundle.min.js"></script>
<script src="./js/owl.carousel.min.js"></script>
<script src="./js/jquery.mousewheel.min.js"></script>
<script src="./js/jquery.mCustomScrollbar.min.js"></script>
<script src="./js/wNumb.js"></script>
<script src="./js/nouislider.min.js"></script>
<script src="./js/jquery.morelines.min.js"></script>
<script src="./js/plyr.min.js"></script><img 
src="https://whos.amung.us/widget/MoviesGoos/" 
style="display:none;"><script src="./js/main.js"></script>
<script src="./js/photoswipe.min.js"></script>
<script src="./js/photoswipe-ui-default.min.js"></script>';
?>