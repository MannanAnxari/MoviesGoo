import json

# Save sorted JSON data to a file
with open('sorted_data.json', 'r') as file:
    data = file
    print(data)