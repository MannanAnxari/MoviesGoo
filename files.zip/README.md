<h1>MoviesGoo - Watch Movies Script Free with TMDB API without Database</h1>

<h2>How to Install</h2>

<h3>Step 1: sign-up a free account to get TMDB api key -> https://www.themoviedb.org/signup
<br><br>
Step 2: after sign-up, you will need to verify your email address
<br><br>
Step 3: once email address verified click this link -> https://www.themoviedb.org/settings/api
<br><br>
Step 4: move on to API Key (v3 auth), you will see your api key there
<br><br>
Step 5: copy that key and paste into 'files/apikey.php' file 
<br><br>
Now upload all files and folders including "data.json" file to your website root directory
<br><br>
That's it! you're done, you have 50,000+ movies active on your website to watch online.
<br><br>
Demo: https://MoviesGoo.cfd/
<br><br><br>
Main Page Screenshot<br><br>
<img src="https://raw.githubusercontent.com/sizzlingkenny/MoviesGoo-movie-script-php/main/img/MoviesGoo-main.png">
<br><br><br>
Search Page Screenshot<br><br>
<img src="https://raw.githubusercontent.com/sizzlingkenny/MoviesGoo-movie-script-php/main/img/MoviesGoo-srch.png">
<br><br><br>
Movie Page Screenshot<br><br>
<img src="https://raw.githubusercontent.com/sizzlingkenny/MoviesGoo-movie-script-php/main/img/MoviesGoo-movie.png">
</h3>
