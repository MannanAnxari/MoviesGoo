<?php 

$category_page_items_to_show = 6;